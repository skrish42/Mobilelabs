package com.example.mobilelab;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.PopupMenu;
import android.widget.Toast;

public class MainActivityMenu extends AppCompatActivity {

    Button b1, b2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        b1 = findViewById(R.id.b1);
        registerForContextMenu(b1);

        b2 = findViewById(R.id.b2);
        b2.setOnClickListener(new View.OnClickListener() {

            //THIS IS FOR POPUP MENU
            @Override
            public void onClick(View v) {
                //Creating the instance of PopupMenu
                PopupMenu popup = new PopupMenu(MainActivityMenu.this, b1);
                //Inflating the Popup using xml file
                popup.getMenuInflater().inflate(R.menu.popup_menu, popup.getMenu());

                //registering popup with OnMenuItemClickListener
                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @RequiresApi(api = Build.VERSION_CODES.O)
                    public boolean onMenuItemClick(MenuItem item) {
                        Toast.makeText(MainActivityMenu.this," " + item.getContentDescription(), Toast.LENGTH_SHORT).show();
                        return true;
                    }
                });

                popup.show();//showing popup menu
            }
        });

    }

    //THIS IS FOR CONTEXT MENU
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.context_menu, menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.teaminfo:
                Intent intent = new Intent(getBaseContext(), MainActivityBroadcastOptions.class);
                startActivity(intent);
                return true;
            case R.id.update:
                Toast.makeText(getApplicationContext(),"Current Version: 1.0.1 \n Next Update on March 2023", Toast.LENGTH_LONG).show();
                return true;
            default:
                return super.onContextItemSelected(item);
        }
    }


        public boolean onCreateOptionsMenu (Menu menu){
            getMenuInflater().inflate(R.menu.main_menu, menu);
            return true;
        }

        @Override
        public boolean onOptionsItemSelected (MenuItem item){
            switch (item.getItemId()) {
                case R.id.menu_item1:
                    Toast.makeText(getApplicationContext(), "You are taken to Home page", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(getBaseContext(), MainActivityBroadcastOptions.class);
                    startActivity(intent);
                    return true;
                case R.id.menu_item2:
                    Toast.makeText(getApplicationContext(), "You are taken to About page", Toast.LENGTH_SHORT).show();
                    Intent intent1 = new Intent(getBaseContext(), MainActivityHardwareSupportOption.class);
                    startActivity(intent1);
                    return true;
                case R.id.menu_item3:
                    Toast.makeText(getApplicationContext(), "Thank you, come again !", Toast.LENGTH_SHORT).show();
                    Intent intent2 = new Intent(getBaseContext(), MainActivityExtrasOptions.class);
                    startActivity(intent2);
                    return true;
                default:
                    return super.onOptionsItemSelected(item);
            }
        }

    }